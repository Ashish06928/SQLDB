INSERT INTO [dbo].[User] (FirstName, LastName, UserName, Password)
VALUES ('Ashish','Vishwakarma','ashish06928@gmail.com','abc');